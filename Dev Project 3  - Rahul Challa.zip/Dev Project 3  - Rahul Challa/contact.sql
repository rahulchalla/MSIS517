-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2017 at 12:48 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rahul_proj`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `email` varchar(60) NOT NULL,
  `message` varchar(500) NOT NULL,
  `roc` varchar(20) NOT NULL,
  `time_stamp` timestamp NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `username`, `subject`, `email`, `message`, `roc`, `time_stamp`) VALUES
(1, 'rahul', 'New Form Submitted', 'rahul.challa@outlook.com', 'hiii', 'Job Offer', '2017-05-01 22:44:37'),
(2, 'anurag.beeram7@gmail.com', 'New Form Submitted', 'anurag.beeram7@gmail.com', 'heyyyy', 'Mentoring', '2017-05-01 22:45:08'),
(3, 'rama', 'New Form Submitted', 'rama@wkkb.com', 'random text', 'Collaboration', '2017-05-01 22:45:33'),
(4, 'vamshi', 'New Form Submitted', 'vamshi@gmail.com', 'zxcvbnm', 'Mentoring', '2017-05-01 22:46:17'),
(5, 'challa', 'New Form Submitted', 'challa@gmail.com', 'random text', 'Job Offer', '2017-05-01 22:46:49'),
(6, 'bob', 'New Form Submitted', 'bob@yahoo.com', 'hey all', 'Job Offer', '2017-05-01 22:47:19');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
