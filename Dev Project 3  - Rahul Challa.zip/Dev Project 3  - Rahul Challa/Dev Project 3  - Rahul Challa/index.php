<html>
<script>

function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function checkCookie() {
    var user=getCookie("username");
    if (user != "") {
        alert("Welcome again " + user);
    } else {
       user = prompt("Please enter your firstname, lastname:","");
       if (user != "" && user != null) {
           setCookie("username", user, 10);
       }
    }
}

</script>
<body onload="checkCookie()">

<title>HomePage!</title>
<link href="css1/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
 <link href="css1/dashboard.css" rel="stylesheet">
<link href="css1/style.css" rel='stylesheet' type='text/css' />


<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<!-- start menu -->
 <script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
<link rel="stylesheet" href="jquery-ui.css"> 
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96373627-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<script src="../js/jquery.js"></script>
<script>
	$(document).ready(
		function(){
			$(".pop1").on('click', function(){
				$(".box").slideDown("slow");
			});

			$(".close").on('click', function(){
				$(".box").slideUp("slow");
		});
	});
</script>

<style>
	.box{
		background-color: white ;
		height:200px;
		width:400px;
		position: absolute;
		left:35%;
		top:30%;
		display:none;
		text-align: center;
		border: 2px solid black;
	}
	.close{
		float:right;
	}
	#draggable {
    width: 100px;
    height: 100px;
    background: #ccc;
    padding-left: 20px;
    left: 25px;
    top: 30px;
  }
  #droppable {
    position: absolute;
    left: 250px;
    top: 40px;
    width: 125px;
    height: 125px;
    background: #999;
    color: red;
    padding: 10px;
  }
</style>
<body>
<!-- header -->	`

<div class="col-sm-3 col-md-2 sidebar">
		 <div class="sidebar_top">
			 <h1>Resume</h1>
			
			 	 
        
            <div class="profile-photo-container">
          <img src="images/rahul.jpg" alt="Profile Photo" class="img-responsive">  
          <div class="profile-photo-overlay"></div>
        </div>
        
      
		 </div>
		<div class="details">
			<table>

		 	<h3>+1 (510) 399-9596</h3>
			<h3>rahul.challa1@marist.edu</h3>
			<h3>99 Delafield Street</h3>
			<h3>Poughkeepsie</h3>
			<h3>New York - 12601</h3>
<br>			
			 <a class="pop1" href="#" >
  <h3>Download Resume</h3>
</a>
		
		</table>
	</div>
		<div class="clearfix"></div>
</div>
<!---->
<link href="css1/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	<!---//pop-up-box---->			
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
	 <div class="content">
		 <div class="details_header">
			 <ul>
				 <li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>HOME</a></li>
				 
				 <li><a href="skillset.php"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span>SKILL SET</a></li>
				 <li><a href="portfolio.php"><span class="glyphicon glyphicon-search" aria-hidden="true"></span>WORK EXPERIENCE</a></li>
				 <li><a href="contact.php"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span>CONTACT</a></li>
				
				 
				 
			 </ul>
		 </div>
		 <div class="company">
			 <h3 class="clr1">Rahul Challa</h3>
			 <div class="company_details">
				 <h4>About Myself and Career Objective<span></span></h4>
				 <h6>My name is Rahul Challa. I am from India. Presently pursuing my Masters in Information Systems at Marist College, Poughkeepsie.</h6>
				 <p class="cmpny1">"Dream to work for an innovative Organization that will allow me the opportunity to make the most of my potential and discover new horizons and enable me to perform best in the Organization. Also to gain more valuable experience while enhancing the work surroundings considering the global market".

				</p>
			 </div>
		</div>
		<div class="copywrite">
			 <p>© 2017 Rahul Challa Resume. All Rights Reserved</p>
		</div>
	 </div>
</div>
<!---->
<div class="box">
	<img class="close" src="images/close.png" width="30"/>
	<div>
		<p>Perform Captcha</p>
		<div id="droppable">Drop here</div>
		<div id="draggable">Drag me</div>
		<iframe id="my_iframe" style="display:none;"></iframe>
		<script>
$( "#draggable" ).draggable();
$( "#droppable" ).droppable({
  drop: function() {   
  	//window.location.=url;
    // window.open(url, 'download'); 
    window.location.href = 'rcr.pdf';
    }
});
</script>

	</div>
</div>
</body>
</html>

